import "./styles/App.css";
import { useState, useEffect } from "react";
import { fetchData } from "./util/persistence";
import WorkoutForm from "./components/WorkoutForm";
import WorkoutList from "./components/WorkoutList";

const blankWorkout = { id: "", sets: "", name: "", reps: "" };

function App() {
  const [workouts, setWorkouts] = useState([]);
  const [workoutToEdit, setWorkoutToEdit] = useState(blankWorkout);

  const APIURL = "http://localhost:3000/workout/";

  function editWorkout(workout) {
    setWorkoutToEdit(workout);
  }

  function mutateWorkout(workout) {
    if (workout.id !== "") {
      // PUT
      updateWorkout(workout);
    } else {
      // POST
      createWorkout(workout);
    }
  }

  async function updateWorkout(workout) {
    try {
      console.log("update");
      await fetchData(
        `${APIURL}/${workout.id}`,
        (updatedWorkout) => {
          setWorkouts(
            workouts.map((w) =>
              w.id === updatedWorkout.id ? { ...updatedWorkout } : w
            )
          );
        },
        "PUT",
        workout
      );
    } catch (error) {
      console.error("Error updating workout:", error);
    }
  }

  async function createWorkout(workout) {
    try {
      console.log("create");
      await fetchData(
        APIURL,
        (newWorkout) => {
          setWorkouts([...workouts, newWorkout]);
        },
        "POST",
        workout
      );
    } catch (error) {
      console.error("Error creating workout:", error);
    }
  }

  function deleteWorkoutById(workoutId) {
    try {
      // Remove via API - JSONServer
      fetchData(`${APIURL}/${workoutId}`, () => {}, "DELETE");
      // Remove from workouts array via setWorkouts()
      setWorkouts([...workouts.filter((w) => w.id !== workoutId)]);
    } catch (error) {
      console.error("Error deleting workout:", error);
    }
  }

  function getAllWorkouts() {
    try {
      // Fetch all workout data
      fetchData(APIURL, (data) => setWorkouts(data.workouts || []));
    } catch (error) {
      console.error("Error fetching workouts:", error);
    }
  }

  useEffect(() => {
    // Fetch all workouts on component mount
    getAllWorkouts();
  }, []);

  return (
    <div>
      <div className="container mt-4 text-center">
        <h1 className="mb-4">Workout Planner</h1>
      </div>
      <WorkoutForm
        blankWorkout={blankWorkout}
        workoutToEdit={workoutToEdit}
        mutateWorkout={mutateWorkout}
      />

      <WorkoutList
        workouts={workouts}
        deleteWorkoutById={deleteWorkoutById}
        editWorkout={editWorkout}
      />
    </div>
  );
}

export default App;
