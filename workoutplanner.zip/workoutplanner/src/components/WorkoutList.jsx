function WorkoutList({ workouts, deleteWorkoutById, editWorkout }) {
  return (
    <div>
      <h1 className="container mt-4"></h1>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Sets</th>
            <th>Reps</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {workouts.map((workout) => (
            <tr key={workout.id}>
              <td>{workout.id}</td>
              <td>{workout.name}</td>
              <td>{workout.sets}</td>
              <td>{workout.reps}</td>
              <td>
                <button
                  className="btn btn-primary btn-sm me-2"
                  onClick={() => editWorkout(workout)}
                >
                  Edit
                </button>
                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => deleteWorkoutById(workout.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default WorkoutList;
