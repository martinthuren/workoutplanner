import { useState, useEffect } from 'react';

function WorkoutForm({ blankWorkout, workoutToEdit, updateWorkout, mutateWorkout }) {
  const [workout, setWorkout] = useState({ ...blankWorkout });

  useEffect(() => {
    setWorkout(workoutToEdit);
  }, [workoutToEdit]);

  function handleChange(event) {
    const value = event.target.value;
    const name = event.target.id;
    setWorkout({ ...workout, [name]: value });
  }

  function handleSubmit(event) {
    event.preventDefault();
    console.log('submit', workout);
    mutateWorkout(workout);
  }

  return (
    <div className="container mt-4">
      <h1 className="mb-4">Add Exercise</h1>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Name of Exercise</label>
          <input
            id="name"
            type="text"
            className="form-control"
            placeholder="Exercise name"
            value={workout.name}
            onChange={handleChange}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="sets" className="form-label">Sets</label>
          <input
            id="sets"
            type="number"
            className="form-control"
            min="0"
            max="120"
            placeholder="Number of sets"
            value={workout.sets}
            onChange={handleChange}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="reps" className="form-label">Reps</label>
          <input
            id="reps"
            type="number"
            className="form-control"
            min="0"
            max="120"
            placeholder="Number of reps"
            value={workout.reps}
            onChange={handleChange}
          />
        </div>

        <button className="btn btn-success me-2" type="submit">Save</button>
        <button className="btn btn-secondary" onClick={() => setWorkout(blankWorkout)}>Reset</button>
      </form>
    </div>
  );
}

export default WorkoutForm;
